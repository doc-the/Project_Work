from django.apps import AppConfig


class OnlyToysConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'only_toys'
