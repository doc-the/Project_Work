from django.shortcuts import render

def only_toys_home(request):
    return render(request, 'main/about.html')
