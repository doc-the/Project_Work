from django.urls import path
from . import views

# При переходе по admin, будет переходить на админку
urlpatterns = [
        path('', views.only_toys_home, name='only_toys_home'),
]
