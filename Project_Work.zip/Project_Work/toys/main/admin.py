from django.contrib import admin
from .models import Toys, Users, Review, Favorite, Order

# Register your models here.
admin.site.register(Toys)
admin.site.register(Users)
admin.site.register(Review)
admin.site.register(Favorite)
admin.site.register(Order)
