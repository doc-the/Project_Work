from django.urls import path
from . import views

# При переходе по admin, будет переходить на админку
urlpatterns = [
        path('', views.index, name='home'),
        path('registration_user', views.registration_user, name='registration_user'),
        path('authorization_user', views.authorization_user, name='authorization_user'),
        path('registration/', views.registration_user, name='registration'),
        path('register/', views.register, name='register'),
        path('login/', views.login, name='login'),
]
