from django.shortcuts import render, redirect
from django.contrib import messages
from .models import Toys, Users

def index(request):
    query = request.GET.get('q')  # Получаем поисковой запрос из GET-параметра

    # Если есть поисковой запрос, фильтруем игрушки по названию
    if query:
        # Приводим первую букву запроса к верхнему регистру, а остальные к нижнему
        query = query.capitalize()
        toys = Toys.objects.filter(title__istartswith=query)
    else:
        toys = Toys.objects.all()

    return render(request, 'main/index.html', {'toys': toys})

def registration_user(request):
    return render(request, 'main/registration_user.html')

def authorization_user(request):
    return render(request, 'main/authorization_user.html')

def register(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')
        surname = request.POST.get('surname')
        first_name = request.POST.get('first_name')
        last_name = request.POST.get('last_name')
        address = request.POST.get('address')
        phone = request.POST.get('phone')

        # Создаем объект пользователя, но не сохраняем его в базе данных
        user = Users(email=email, password=password, surname=surname, first_name=first_name, last_name=last_name,
                     address=address, phone=phone)

        # Сохраняем пользователя в базу данных
        user.save()

        return redirect('home')  # Или куда-то еще, куда вы хотите перенаправить пользователя после успешной регистрации
    return render(request, 'registration/register.html')


def login(request):
    if request.method == 'POST':
        email = request.POST.get('email')
        password = request.POST.get('password')

        try:
            # Пытаемся найти пользователя в базе данных
            user = Users.objects.get(email=email, password=password)
            # Выводим данные пользователя в консоль для проверки
            print(f'User Full Name: {user.first_name} {user.last_name}')
            print(f'User Email: {user.email}')
            # Если пользователь найден, сохраняем его данные в объекте запроса
            request.user_fullname = f'{user.first_name} {user.last_name}'
            request.user_email = user.email
            # Выводим сообщение о приветствии
            messages.success(request, f'Добро пожаловать, {user.first_name} {user.last_name}!')
            #return redirect('home')  # или куда-то еще, куда нужно перенаправить пользователя
        except Users.DoesNotExist:
            # Если пользователь с такими данными не найден, выводим сообщение об ошибке
            messages.error(request, 'Неверный логин или пароль')

    return render(request, 'main/authorization_user.html', {
        'user_fullname': getattr(request, 'user_fullname', None),
        'user_email': getattr(request, 'user_email', None),
    })



def home(request):
    # Получаем имя пользователя и email из объекта запроса
    user_fullname = request.user_fullname
    user_email = request.user_email
    if user_fullname and user_email:
        # Ваш код для авторизованного пользователя
        return render(request, 'main/index.html', {'user_fullname': user_fullname, 'user_email': user_email})
    else:
        # Ваш код для неавторизованного пользователя
        return redirect('login')  # или куда-то еще
