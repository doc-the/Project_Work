from django.db import models

class Toys(models.Model):
    title = models.CharField('Название', max_length=100)
    descr = models.TextField('Описание')
    w_h = models.CharField('Высота-ширина',max_length=100)

    price = models.IntegerField('Цена')
    number_of_orders = models.IntegerField('Кол-во заказов')


    type = models.CharField('Тип', max_length=100)
    color = models.CharField('Цвет', max_length=100)
    image = models.ImageField('Фотография', upload_to='static/main/img/', default='static/main/img/logo.svg')


    def __str__(self):
        return self.title

    class Meta:
        verbose_name = 'Игрушка'
        verbose_name_plural = 'Игрушки'



class Users(models.Model):
    email = models.EmailField('Почта', unique=True)
    password = models.CharField('Пароль', max_length=100)
    surname = models.CharField('Фамилия', max_length=25)
    first_name = models.CharField('Имя', max_length=25)
    last_name = models.CharField('Отчество', max_length=25)
    address = models.CharField('Адрес доставки', max_length=255)
    phone = models.CharField('Телефон', max_length=15)

    def __str__(self):
        return self.surname

    class Meta:
        verbose_name = 'Пользователь'
        verbose_name_plural = 'Пользователи'


class Review(models.Model):
    toy = models.ForeignKey(Toys, on_delete=models.CASCADE, verbose_name='Игрушка')
    user = models.ForeignKey(Users, on_delete=models.CASCADE, verbose_name='Пользователь')
    review_text = models.TextField('Отзыв')

    def __str__(self):
        return f"Отзыв на игрушку '{self.toy.title}' от пользователя {self.user.surname} {self.user.first_name}"

    class Meta:
        verbose_name = 'Отзыв'
        verbose_name_plural = 'Отзывы'

class Favorite(models.Model):
    user = models.ForeignKey(Users, on_delete=models.CASCADE, verbose_name='Пользователь')
    toy = models.ForeignKey(Toys, on_delete=models.CASCADE, verbose_name='Избранная игрушка')

    def __str__(self):
        return f"{self.user.surname} {self.user.first_name} - {self.toy.title}"

    class Meta:
        verbose_name = 'Избранное'
        verbose_name_plural = 'Избранные'

class Order(models.Model):
    user = models.ForeignKey(Users, on_delete=models.CASCADE, verbose_name='Пользователь')
    toy = models.ForeignKey(Toys, on_delete=models.CASCADE, verbose_name='Игрушка')
    quantity = models.PositiveIntegerField('Количество')
    total_price = models.DecimalField('Общая стоимость', max_digits=10, decimal_places=2)

    def __str__(self):
        return f"{self.user.surname} {self.user.first_name} - {self.toy.title}"

    class Meta:
        verbose_name = 'Заказ'
        verbose_name_plural = 'Заказы'


