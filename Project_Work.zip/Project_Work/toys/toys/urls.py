from django.contrib import admin
from django.urls import path, include

from django.conf import settings
from django.conf.urls.static import static


# При переходе по admin, будет переходить на админку
urlpatterns = [
    path('admin/', admin.site.urls),
    path('', include('main.urls')),
    path('only_toys/', include('only_toys.urls')),

]

